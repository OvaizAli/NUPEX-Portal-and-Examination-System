#include "viewmarks.h"
#include "ui_viewmarks.h"
#include<facultyportion.h>
#include"facultyportion.h"
ViewMarks::ViewMarks(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ViewMarks)
{
    ui->setupUi(this);
}

ViewMarks::~ViewMarks()
{
    delete ui;
}

void ViewMarks::on_pushButton_clicked()
{
    FacultyPortion connect;
    QSqlQueryModel *model = new QSqlQueryModel();
    courses=ui->course->text();
    sections=ui->section->text();
    connect.connOpen();
    QSqlQuery *qry = new QSqlQuery(connect.myData);
    qry->prepare("select * from '"+courses+"' where Section='"+sections+"'");
    qry->exec();
    model->setQuery(*qry);
    ui->tableView->setModel(model);
    connect.connClose();
}
