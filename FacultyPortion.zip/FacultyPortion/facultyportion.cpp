#include "facultyportion.h"
#include "ui_facultyportion.h"
#include<updateattendance.h>
#include"updateattendance.h"
#include"viewattendance.h"
#include<viewattendance.h>
#include<updatemarks.h>
#include"updatemarks.h"
#include"viewmarks.h"
#include<viewmarks.h>
FacultyPortion::FacultyPortion(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::FacultyPortion)
{
    ui->setupUi(this);
}

FacultyPortion::~FacultyPortion()
{
    delete ui;
}

void FacultyPortion::on_pushButton_clicked()
{
    UpdateAttendance *up= new UpdateAttendance;
     this->hide();
     up->setModal(true);
     up->exec();

}

void FacultyPortion::on_pushButton_2_clicked()
{
    ViewAttendance *va= new ViewAttendance;
     this->hide();
     va->setModal(true);
     va->exec();
}

void FacultyPortion::on_pushButton_3_clicked()
{
    UpdateMarks *um= new  UpdateMarks;
     this->hide();
     um->setModal(true);
     um->exec();
}

void FacultyPortion::on_pushButton_4_clicked()
{
    ViewMarks *vm= new  ViewMarks;
     this->hide();
     vm->setModal(true);
      vm->exec();
}
