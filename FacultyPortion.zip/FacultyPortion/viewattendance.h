#ifndef VIEWATTENDANCE_H
#define VIEWATTENDANCE_H

#include <QDialog>

namespace Ui {
class ViewAttendance;
}

class ViewAttendance : public QDialog
{
    Q_OBJECT

public:
    explicit ViewAttendance(QWidget *parent = nullptr);
    ~ViewAttendance();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ViewAttendance *ui;
};

#endif // VIEWATTENDANCE_H
