#include "updateattendance.h"
#include "ui_updateattendance.h"
#include<facultyportion.h>
#include"facultyportion.h"
UpdateAttendance::UpdateAttendance(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateAttendance)
{
    ui->setupUi(this);

}
UpdateAttendance::~UpdateAttendance()
{
    delete ui;
}

void UpdateAttendance::on_pushButton_clicked()
{
    FacultyPortion connect;
    QSqlQueryModel *model = new QSqlQueryModel();
    courses=ui->course->text();
    sections=ui->section->text();
    connect.connOpen();
    QSqlQuery query;
    query.prepare("select ID from Faculty SET Lectures = Lectures + 1 WHERE Course='"+courses+"' and  Section='"+sections+"'");
    query.exec();
    connect.connOpen();
    QSqlQuery *qry = new QSqlQuery(connect.myData);
    qry->prepare("select ID from Attendance where Course='"+courses+"' and  Section='"+sections+"'");
    qry->exec();
    model->setQuery(*qry);
    ui->comboBox->setModel(model);
    connect.connClose();

}

void UpdateAttendance::on_comboBox_currentIndexChanged(const QString &arg1)
{
     id=ui->comboBox->currentText();
}

void UpdateAttendance::on_pushButton_2_clicked()
{
    FacultyPortion connect;
    connect.connOpen();
    QSqlQuery query;
    query.prepare("UPDATE Attendance SET Lectures = Lectures + 1 WHERE Course='"+courses+"' and  Section='"+sections+"'");
    query.exec();
    connect.connClose();
     if(ui->present->isChecked() or ui->leave->isChecked())
    {       QSqlQuery query;
            query.prepare("UPDATE Attendance SET Att = Att + 1 WHERE ID='"+id+"'");
            query.exec();
            connect.connClose();
    }
}
