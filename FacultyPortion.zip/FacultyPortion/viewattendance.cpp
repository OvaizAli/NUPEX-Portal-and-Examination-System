#include "viewattendance.h"
#include "ui_viewattendance.h"
#include<facultyportion.h>
#include"facultyportion.h"
ViewAttendance::ViewAttendance(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ViewAttendance)
{
    ui->setupUi(this);
    FacultyPortion connect;
    connect.connOpen();
    QSqlQuery query;
    query.prepare("UPDATE Attendance SET Attendance=(Att/Lectures)*100");
    query.exec();
    connect.connClose();
}

ViewAttendance::~ViewAttendance()
{
    delete ui;
}

void ViewAttendance::on_pushButton_clicked()
{
    FacultyPortion connect;
    QSqlQueryModel *model = new QSqlQueryModel();
    QString courses,sections;
    courses=ui->course->text();
    sections=ui->section->text();
    connect.connOpen();
    QSqlQuery *qry = new QSqlQuery(connect.myData);
    qry->prepare("select ID,Name,Attendance from Attendance where Course='"+courses+"' and  Section='"+sections+"'");
    qry->exec();
    model->setQuery(*qry);
    ui->tableView->setModel(model);
    connect.connClose();
}
