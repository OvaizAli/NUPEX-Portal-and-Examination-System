#ifndef VIEWMARKS_H
#define VIEWMARKS_H

#include <QDialog>

namespace Ui {
class ViewMarks;
}

class ViewMarks : public QDialog
{
    Q_OBJECT

public:
    QString courses,sections;
    explicit ViewMarks(QWidget *parent = nullptr);
    ~ViewMarks();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ViewMarks *ui;
};

#endif // VIEWMARKS_H
