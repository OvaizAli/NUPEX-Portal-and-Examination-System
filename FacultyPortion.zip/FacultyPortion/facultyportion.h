#ifndef FACULTYPORTION_H
#define FACULTYPORTION_H

#include <QMainWindow>
#include<QtSql>
#include<QDebug>
#include<QFileInfo>


namespace Ui {
class FacultyPortion;
}

class FacultyPortion : public QMainWindow
{
    Q_OBJECT
public:
     QSqlDatabase myData;

     void connClose()
     {
         myData.close();
       //  myData.removeDatabase(QSqlDatabase::defaultConnection);
     }
     bool connOpen()
     {
         myData = QSqlDatabase::addDatabase("QSQLITE");

         myData.setDatabaseName("C:/Users/dell/Desktop/Data.db");

         if(!myData.open())
         {
             qDebug()<<"Failed to open";
             return 0;
         }
         else
         {
              qDebug()<<"Connected..";
              return 1;
         }
     }


public:
    explicit FacultyPortion(QWidget *parent = nullptr);
    ~FacultyPortion();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::FacultyPortion *ui;
};

#endif // FACULTYPORTION_H
