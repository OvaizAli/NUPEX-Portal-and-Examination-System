#include "updatemarks.h"
#include "ui_updatemarks.h"
#include<facultyportion.h>
#include"facultyportion.h"
UpdateMarks::UpdateMarks(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UpdateMarks)
{
    ui->setupUi(this);
}

UpdateMarks::~UpdateMarks()
{
    delete ui;
}

void UpdateMarks::on_pushButton_clicked()
{
    FacultyPortion connect;
    QSqlQueryModel *model = new QSqlQueryModel();
    courses=ui->course->text();
    sections=ui->section->text();
    connect.connOpen();
    QSqlQuery *qry = new QSqlQuery(connect.myData);
    qry->prepare("select ID from '"+courses+"' where Section='"+sections+"'");
    qry->exec();
    model->setQuery(*qry);
    ui->comboBox->setModel(model);
    connect.connClose();
}

void UpdateMarks::on_comboBox_currentIndexChanged(const QString &arg1)
{
    id=ui->comboBox->currentText();
}

void UpdateMarks::on_pushButton_2_clicked()
{
    double  mid1=0.0, mid2=0.0, quiz1=0.0, quiz2=0.0 , quiz3=0.0, Assignment=0.0, Final=0.0,Total=0.0;

    mid1 = ui->doubleSpinBox->value();
    mid2 = ui->doubleSpinBox_2->value();
    quiz1 = ui->doubleSpinBox_3->value();
    quiz2 = ui->doubleSpinBox_4->value();
    quiz3 = ui->doubleSpinBox_5->value();
    Assignment = ui->doubleSpinBox_6->value();
    Final = ui->doubleSpinBox_7->value();
    Total= mid1 + mid2 + quiz1 + quiz2 + quiz3 + Assignment + Final;
    FacultyPortion connect;
    connect.connOpen();
    QSqlQuery qry;
    qry.prepare("UPDATE'"+courses+"' SET MID1= mid1 , MID2= mid2 , Quiz1= quiz1 , Quiz2= quiz2  , Quiz3= quiz3 , Assignment= Assignment , Final= Final ,Total= Total where ID='"+id+"'");
    qry.exec();
     connect.connClose();
    }
